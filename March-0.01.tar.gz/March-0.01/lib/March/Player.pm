use strict;
use warnings;
package March::Player;
$March::Player::VERSION = '0.01';
1;

__END__

=pod

=encoding UTF-8

=head1 NAME

March::Player

=head1 VERSION

version 0.01

=head1 AUTHOR

David Farrell <sillymoos@cpan.org>

=head1 COPYRIGHT AND LICENSE

This software is Copyright (c) 2014 by David Farrell.

This is free software, licensed under:

  The (two-clause) FreeBSD License

=cut
